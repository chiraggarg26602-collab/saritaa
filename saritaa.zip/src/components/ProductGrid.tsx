const products = [
  {
    id: 1,
    name: "Hand-Block Print Kurti Set",
    price: "₹3,499",
    image: "https://images.unsplash.com/photo-1583391265517-35bbd0eb1b4b?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 2,
    name: "Maroon Gota Patti Lehenga",
    price: "₹18,500",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 3,
    name: "Classic Bandhani Saree",
    price: "₹6,200",
    image: "https://images.unsplash.com/photo-1610113221081-3069c991f2be?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 4,
    name: "Leheriya Silk Dupatta",
    price: "₹2,100",
    image: "https://images.unsplash.com/photo-1609505848912-b7c3b8b4beda?q=80&w=800&auto=format&fit=crop"
  }
];

export default function ProductGrid() {
  return (
    <section className="py-24 bg-stone-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl font-serif text-rose-950 mb-2">Heritage Arrivals</h2>
            <p className="text-stone-600 font-light">Curated traditional pieces for your timeless elegance.</p>
          </div>
          <a href="#" className="hidden md:block text-sm font-medium text-rose-900 border-b border-rose-900 pb-1 hover:text-rose-950 hover:border-rose-950 transition-colors">
            View All
          </a>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
          {products.map((product) => (
            <div key={product.id} className="group cursor-pointer">
              <div className="relative aspect-[3/4] overflow-hidden bg-stone-200 mb-4 border border-stone-200">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-rose-950/0 group-hover:bg-rose-950/10 transition-colors duration-300"></div>
                <button className="absolute bottom-4 left-4 right-4 bg-rose-900 text-amber-50 py-3 text-sm font-medium opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 shadow-sm">
                  Add to Cart
                </button>
              </div>
              <h3 className="text-stone-900 font-medium">{product.name}</h3>
              <p className="text-rose-800 text-sm mt-1 font-medium">{product.price}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
