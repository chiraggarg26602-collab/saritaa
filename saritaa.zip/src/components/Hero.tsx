export default function Hero() {
  return (
    <div className="relative w-full h-[85vh] min-h-[600px] bg-stone-100 flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1583391733959-b14197c36a43?q=80&w=2070&auto=format&fit=crop" 
          alt="Rajasthani Fashion background" 
          className="w-full h-full object-cover opacity-95"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30"></div>
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto mt-16">
        <span className="text-amber-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block">
          Authentic Indian Craft
        </span>
        <h1 className="text-5xl md:text-7xl font-serif text-white mb-6 tracking-tight drop-shadow-lg">
          The Royal Threads of Rajasthan
        </h1>
        <p className="text-lg md:text-xl text-stone-100 mb-10 max-w-2xl mx-auto font-light drop-shadow">
          Discover our vibrant collection of handcrafted Bandhani, exquisite block prints, and timeless Lehengas designed for the modern ethnic wardrobe.
        </p>
        <button className="bg-rose-800 text-amber-50 px-10 py-4 uppercase tracking-widest text-sm font-bold hover:bg-rose-950 transition-colors shadow-xl">
          Shop the Heritage
        </button>
      </div>
    </div>
  );
}
