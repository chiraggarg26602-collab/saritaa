import { ShoppingBag, Search, Menu } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="w-full bg-stone-50/90 backdrop-blur-md fixed top-0 z-50 border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <button className="p-2 -ml-2 mr-2 md:hidden text-stone-600 hover:text-rose-900">
              <Menu className="h-6 w-6" />
            </button>
            <a href="#" className="text-2xl font-serif font-bold tracking-wider text-rose-950">
              SARITAA
            </a>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <a href="#" className="text-sm font-medium text-stone-700 hover:text-rose-900 transition-colors">Sarees</a>
            <a href="#" className="text-sm font-medium text-stone-700 hover:text-rose-900 transition-colors">Kurtis & Suits</a>
            <a href="#" className="text-sm font-medium text-stone-700 hover:text-rose-900 transition-colors">Lehengas</a>
            <a href="#" className="text-sm font-medium text-stone-700 hover:text-rose-900 transition-colors">Heritage</a>
          </div>

          <div className="flex items-center space-x-4">
            <button className="text-stone-600 hover:text-rose-900 p-2">
              <Search className="h-5 w-5" />
            </button>
            <button className="text-stone-600 hover:text-rose-900 p-2 relative">
              <ShoppingBag className="h-5 w-5" />
              <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-rose-700"></span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
