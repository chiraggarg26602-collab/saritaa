import { Instagram, Facebook, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-stone-950 text-stone-300 py-16 border-t-[6px] border-rose-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-1">
            <h2 className="text-2xl font-serif font-bold tracking-wider mb-6 text-amber-50">SARITAA</h2>
            <p className="text-stone-400 text-sm leading-relaxed mb-6">
              Elevating everyday fashion with the vibrant heritage, sustainable block prints, and timeless craftsmanship of Rajasthan.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-stone-400 hover:text-amber-50 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-stone-400 hover:text-amber-50 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-stone-400 hover:text-amber-50 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6 text-amber-50">Shop</h3>
            <ul className="space-y-4 text-sm text-stone-400">
              <li><a href="#" className="hover:text-amber-50 transition-colors">Bandhani Sarees</a></li>
              <li><a href="#" className="hover:text-amber-50 transition-colors">Block Print Kurtis</a></li>
              <li><a href="#" className="hover:text-amber-50 transition-colors">Bridal Lehengas</a></li>
              <li><a href="#" className="hover:text-amber-50 transition-colors">Dupattas & Accessories</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6 text-amber-50">Support</h3>
            <ul className="space-y-4 text-sm text-stone-400">
              <li><a href="#" className="hover:text-amber-50 transition-colors">FAQ</a></li>
              <li><a href="#" className="hover:text-amber-50 transition-colors">Shipping & Returns</a></li>
              <li><a href="#" className="hover:text-amber-50 transition-colors">Size Guide</a></li>
              <li><a href="#" className="hover:text-amber-50 transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6 text-amber-50">Newsletter</h3>
            <p className="text-stone-400 text-sm mb-4">
              Subscribe to receive updates on new collections and exclusive cultural showcases.
            </p>
            <form className="flex" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="bg-stone-900 border border-stone-800 text-white px-4 py-2 w-full focus:outline-none focus:border-rose-800 text-sm"
              />
              <button 
                type="submit" 
                className="bg-rose-900 text-amber-50 px-4 py-2 text-sm font-medium hover:bg-rose-800 transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-stone-800 mt-16 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-stone-500">
          <p>&copy; {new Date().getFullYear()} Saritaa Fashion. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-stone-300 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-stone-300 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
